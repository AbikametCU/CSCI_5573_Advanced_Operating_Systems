#!/bin/bash

rmmod syscall_intercept
insmod syscall_intercept.ko
